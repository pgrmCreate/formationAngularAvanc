import { TaskInputDirective } from './task-input.directive';

describe('TaskInputDirective', () => {
  it('should create an instance', () => {
    const directive = new TaskInputDirective();
    expect(directive).toBeTruthy();
  });
});
